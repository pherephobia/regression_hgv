
Data on rodents in a sample of New York City apartments.

