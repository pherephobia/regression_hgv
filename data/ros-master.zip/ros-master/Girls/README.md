
Proportion of girl births in 24 successive months in Vienna, 1908-1909, out of
an average of 3900 births per month.

Source: von Mises R. Probability, Statistics, and Truth. 2nd ed. New York:
Dover; 1957.

