
Data from an experiment on the effect on milk production of an additive to the
diet of 50 cows.

