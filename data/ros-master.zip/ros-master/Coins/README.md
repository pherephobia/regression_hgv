
Data from a coin-flipping experiment done in a class. Each student flipped a
coin 10 times, and the data is the count of the number of students who saw
exactly 0, 1, 2, ..., 10 heads.

