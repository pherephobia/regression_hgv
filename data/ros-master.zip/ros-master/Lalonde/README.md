
Data from an observational study based upon a randomized experiment that
evaluated the effect of earnings of a job training program called National
Supported Work.

Source: LaLonde RJ. Evaluating the econometric evaluations of training programs
using experimental data. American Economic Review. 1986;76:604-620.

