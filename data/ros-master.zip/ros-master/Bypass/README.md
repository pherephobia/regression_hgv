
Hypothetical data for an experiment to estimate the effect of a new procedure
for coronary bypass surgery that is supposed to help with the postoperative
healing process.

