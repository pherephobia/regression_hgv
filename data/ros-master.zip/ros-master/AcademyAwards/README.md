
Data on Academy Award winners.

Source: Pardoe I, Simonton DK. Applying discrete choice models to predict
Academy Award winners. Journal of the Royal Statistical Society A.
2008;171:375-394.
