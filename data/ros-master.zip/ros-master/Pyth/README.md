
Outcome y and predictors x1, x2 for 40 data points, with a further 20 points
with predictors but no observed outcome.

Source: Gelman A, Nolan D. Teaching Statistics: A Bag of Tricks. 2nd ed. Oxford
University Press; 2017. Section 10.4, p. 160-161.

